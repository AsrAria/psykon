const selectDialogStyle = () => ({
  mainView: {
    width: "600px"
  }
});

export default selectDialogStyle;
