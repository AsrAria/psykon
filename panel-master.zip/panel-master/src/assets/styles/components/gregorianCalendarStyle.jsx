const gregorianCalendarStyle = () => ({
  main: {
    display: "flex",
    paddingTop: "1px"
  },
  selectButton: {
    height: "40px",
    float: "left",
    marginTop: "20px",
    marginRight: "15px"
  }
});

export default gregorianCalendarStyle;
