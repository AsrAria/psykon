# Jitsi Meet on Docker


## Setup

- Make copy of `env.example` with the name `.env`.
- Set values for following variables in `.env`.
    - JWT_APP_ID
    - JWT_APP_SECRET
    - LETSENCRYPT_EMAIL
    - LETSENCRYPT_DOMAIN
    - PUBLIC_URL
- Run `./gen-passwords.sh`.
- Run the following command.
```
mkdir -p ~/.jitsi-meet-cfg/{web/letsencrypt,transcripts,prosody/config,prosody/prosody-plugins-custom,jicofo,jvb,jigasi,jibri}
```
- Run `sudo docker-compose up -d`.
