import Dashboard from "views/Dashboard/Dashboard.jsx";

const indexRoutes = [{ path: "/", component: Dashboard }];

export default indexRoutes;
